/* This file is auto generated, version 12+IntelAtom */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#12+IntelAtom SMP Thu Dec 29 15:40:06 AEDT 2016"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "LINUXIUMONE"
#define LINUX_COMPILER "gcc version 4.9.3 (Ubuntu 4.9.3-8ubuntu2~14.04) "
